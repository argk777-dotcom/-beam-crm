# CRM Балки

Веб-приложение для расчёта прибыли по модели v2.0.

## Запуск локально
npm install
npm run dev

## Публикация на Vercel
1. Загрузить проект в GitHub.
2. Открыть Vercel.
3. Add New Project.
4. Выбрать репозиторий.
5. Deploy.
