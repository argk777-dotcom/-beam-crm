import React, { useMemo, useState, useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import './styles.css';

const VAT = 1.22;
const DEFAULT_FIXED = {
  warehouse: 155000,
  carRent: 120000,
  accounting: 70000,
  salaryGross: 100000,
  insurance: 30000,
};

const starterRows = [
  { sale: 420, buy: 385, meters: 4200, logistics: 53000, commission: 16380 },
];

function money(n) {
  const value = Number.isFinite(n) ? n : 0;
  return new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 0 }).format(Math.round(value)) + ' ₽';
}

function num(v) {
  if (v === '' || v === null || v === undefined) return 0;
  return Number(String(v).replace(',', '.')) || 0;
}

function calcRow(row) {
  const saleVat = num(row.sale) * num(row.meters);
  const buyVat = num(row.buy) * num(row.meters);
  const saleNoVat = saleVat / VAT;
  const buyNoVat = buyVat / VAT;
  const margin = saleNoVat - buyNoVat;
  const operating = margin - num(row.logistics);
  return { saleVat, buyVat, saleNoVat, buyNoVat, margin, operating };
}

function App() {
  const [rows, setRows] = useState(() => {
    const saved = localStorage.getItem('beam_crm_rows');
    return saved ? JSON.parse(saved) : starterRows;
  });
  const [fixed, setFixed] = useState(() => {
    const saved = localStorage.getItem('beam_crm_fixed');
    return saved ? JSON.parse(saved) : DEFAULT_FIXED;
  });

  useEffect(() => localStorage.setItem('beam_crm_rows', JSON.stringify(rows)), [rows]);
  useEffect(() => localStorage.setItem('beam_crm_fixed', JSON.stringify(fixed)), [fixed]);

  const totals = useMemo(() => {
    const rowCalcs = rows.map(calcRow);
    const turnoverVat = rowCalcs.reduce((s, r) => s + r.saleVat, 0);
    const operating = rowCalcs.reduce((s, r) => s + r.operating, 0);
    const commission = rows.reduce((s, r) => s + num(r.commission), 0);
    const ipPayments = num(fixed.warehouse) + num(fixed.carRent) + num(fixed.accounting);
    const fixedExpenses = ipPayments + num(fixed.salaryGross) + num(fixed.insurance);
    const companyProfitBeforeTax = operating - fixedExpenses;
    const profitTax = companyProfitBeforeTax > 0 ? companyProfitBeforeTax * 0.25 : 0;
    const afterProfitTax = companyProfitBeforeTax - profitTax;
    const dividendTax = afterProfitTax > 0 ? afterProfitTax * 0.13 : 0;
    const dividendsToOwner = afterProfitTax - dividendTax;
    const ipToOwner = ipPayments * 0.91;
    const salaryToOwner = num(fixed.salaryGross) * 0.87;
    const ownerBeforeCommission = dividendsToOwner + ipToOwner + salaryToOwner;
    const ownerFinal = ownerBeforeCommission - commission;
    return { rowCalcs, turnoverVat, operating, commission, ipPayments, fixedExpenses, companyProfitBeforeTax, profitTax, afterProfitTax, dividendTax, dividendsToOwner, ipToOwner, salaryToOwner, ownerBeforeCommission, ownerFinal };
  }, [rows, fixed]);

  function updateRow(index, key, value) {
    setRows(rows.map((r, i) => i === index ? { ...r, [key]: value } : r));
  }

  function addRow() {
    setRows([...rows, { sale: '', buy: '', meters: '', logistics: 53000, commission: '' }]);
  }

  function duplicateLast() {
    const last = rows[rows.length - 1] || starterRows[0];
    setRows([...rows, { ...last }]);
  }

  function removeRow(index) {
    setRows(rows.filter((_, i) => i !== index));
  }

  function resetDemo() {
    setRows([
      { sale: 420, buy: 385, meters: 4200, logistics: 53000, commission: 16380 },
      { sale: 420, buy: 385, meters: 4200, logistics: 53000, commission: 16380 },
      { sale: 420, buy: 385, meters: 4200, logistics: 53000, commission: 16380 },
      { sale: 429, buy: 392.86, meters: 4200, logistics: 53000, commission: 21780 },
      { sale: 429, buy: 392.86, meters: 4200, logistics: 53000, commission: 0 },
      { sale: 420, buy: 385, meters: 3300, logistics: 45000, commission: 0 },
      { sale: 425, buy: 385, meters: 3990, logistics: 53000, commission: 0 },
      { sale: 440, buy: 405, meters: 4500, logistics: 53000, commission: 0 },
    ]);
  }

  return <div className="app">
    <header>
      <div>
        <h1>CRM Балки</h1>
        <p>Модель v2.0: НДС 22%, прибыль ООО, дивиденды, ИП, ЗП и комиссия в конце.</p>
      </div>
      <button onClick={resetDemo}>Пример</button>
    </header>

    <section className="cards">
      <Card title="Оборот с НДС" value={money(totals.turnoverVat)} />
      <Card title="Опер. прибыль" value={money(totals.operating)} />
      <Card title="Прибыль ООО" value={money(totals.companyProfitBeforeTax)} />
      <Card title="Тебе чистыми" value={money(totals.ownerFinal)} big />
    </section>

    <section className="panel">
      <div className="panelTitle">
        <h2>Фуры</h2>
        <div className="actions">
          <button onClick={addRow}>+ Добавить фуру</button>
          <button onClick={duplicateLast}>Дублировать</button>
        </div>
      </div>
      <div className="rows">
        {rows.map((row, i) => {
          const c = totals.rowCalcs[i];
          return <div className="truck" key={i}>
            <div className="truckHead">
              <strong>Фура {i + 1}</strong>
              <button className="danger" onClick={() => removeRow(i)}>Удалить</button>
            </div>
            <Field label="Реализация ₽/м.п." value={row.sale} onChange={v => updateRow(i, 'sale', v)} />
            <Field label="Закуп ₽/м.п." value={row.buy} onChange={v => updateRow(i, 'buy', v)} />
            <Field label="Метраж м.п." value={row.meters} onChange={v => updateRow(i, 'meters', v)} />
            <Field label="Логистика ₽" value={row.logistics} onChange={v => updateRow(i, 'logistics', v)} />
            <Field label="Комиссия менеджера ₽" value={row.commission} onChange={v => updateRow(i, 'commission', v)} />
            <div className="rowResult">
              <span>Прибыль фуры до пост. расходов</span>
              <b>{money(c.operating)}</b>
            </div>
          </div>
        })}
      </div>
    </section>

    <section className="panel">
      <h2>Постоянные расходы</h2>
      <div className="grid">
        <Field label="Склад" value={fixed.warehouse} onChange={v => setFixed({ ...fixed, warehouse: v })} />
        <Field label="Аренда машины" value={fixed.carRent} onChange={v => setFixed({ ...fixed, carRent: v })} />
        <Field label="Бухгалтерия" value={fixed.accounting} onChange={v => setFixed({ ...fixed, accounting: v })} />
        <Field label="ЗП грязными" value={fixed.salaryGross} onChange={v => setFixed({ ...fixed, salaryGross: v })} />
        <Field label="Страховые" value={fixed.insurance} onChange={v => setFixed({ ...fixed, insurance: v })} />
      </div>
    </section>

    <section className="panel summary">
      <h2>Расчёт месяца</h2>
      <Line name="Операционная прибыль" value={totals.operating} />
      <Line name="Постоянные расходы ООО" value={-totals.fixedExpenses} />
      <Line name="Прибыль ООО до налога" value={totals.companyProfitBeforeTax} strong />
      <Line name="Налог на прибыль 25%" value={-totals.profitTax} />
      <Line name="НДФЛ с дивидендов 13%" value={-totals.dividendTax} />
      <Line name="Дивиденды на руки" value={totals.dividendsToOwner} />
      <Line name="ИП на руки после 9%" value={totals.ipToOwner} />
      <Line name="ЗП на руки" value={totals.salaryToOwner} />
      <Line name="Доход до комиссии" value={totals.ownerBeforeCommission} strong />
      <Line name="Комиссия менеджера" value={-totals.commission} />
      <Line name="ИТОГО тебе чистыми" value={totals.ownerFinal} final />
    </section>
  </div>;
}

function Card({ title, value, big }) {
  return <div className={big ? 'card big' : 'card'}><span>{title}</span><b>{value}</b></div>;
}
function Field({ label, value, onChange }) {
  return <label className="field"><span>{label}</span><input inputMode="decimal" value={value} onChange={e => onChange(e.target.value)} /></label>;
}
function Line({ name, value, strong, final }) {
  return <div className={final ? 'line final' : strong ? 'line strong' : 'line'}><span>{name}</span><b>{money(value)}</b></div>;
}

createRoot(document.getElementById('root')).render(<App />);
